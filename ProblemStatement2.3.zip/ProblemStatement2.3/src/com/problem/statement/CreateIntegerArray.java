package com.problem.statement;

public class CreateIntegerArray {
	public static void main(String args[]) {
		int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		int i,sum=0;
		for(i=0;i<=14;i++) {
			sum = sum + A[i];
		}
		A[15]=sum;
		System.out.println("The sum of elements is: "+A[15]);
		int avg =0;
		avg = A[15]/15;
		A[16] = avg;
		System.out.println("The average of all elements is: "+A[16]);
		int smallest = A[0];
		for(i=1;i<=14;i++) {
			if(A[i]<smallest) {
				smallest = A[i];
			}
		}
		
		A[17]=smallest;
		System.out.println("The smallest elements is: "+A[17]);
		
	}
}
