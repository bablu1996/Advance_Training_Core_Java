package com.problem.statement1;

import java.util.*;

public class ProbStatement1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		       int n=0,i=0;
		       Scanner sc = new Scanner(System.in);
		       System.out.print("Enter value n : ");
		       n = sc.nextInt();
		       for(i=1; i<=n; i++)
		       {
		    	   if(i%2==0)
		               System.out.println(i+" ");

		       }    

		       System.out.println();
		       
	}

}
