package com.problem.statement;


public class ManipulateTheString {

		public static void main(String[] args) {
			
		
		String txt= "JAVA is Simple";
		
		System.out.println(txt.toUpperCase()); 
		
		System.out.println(txt.toLowerCase()); 
		
		
		String[] words=txt.split("\\s");	
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
		String s[] = txt.split(" "); 
	      String ans = ""; 
	      for (int i = s.length - 1; i >= 0; i--) { 
	        ans += s[i] + " "; 
	      } 
	      System.out.println(ans); 
	    
	      
	      StringBuffer string = new StringBuffer(txt);
	      txt = string.reverse().toString();
	      String [] rev = txt.split(" ");
	      StringBuffer reverse = new StringBuffer();
	      for(int i = rev.length - 1; i >= 0; i--) {
	          reverse.append(rev[i]).append(" ");
	      }
	      System.out.println(reverse.toString());
		
		System.out.println("Total length is: " + txt.length());
		
		
	}
}