package com.problem.statement2;
import java.util.Scanner;

import com.problem.statement2.*;
public class TestRectangle {
	
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int len;
		int bred;
		System.out.println("Enter Length for rectangle1");
		len = sc.nextInt();
		System.out.println("Enter Breadth for rectangle1");
		bred = sc.nextInt();
		Rectangle rec1 = new Rectangle(len,bred);
		rec1.disRecInfo();
		
		
		
		System.out.println("\nEnter Length for rectangle2");
		len = sc.nextInt();
		System.out.println("Enter Breadth for rectangle2");
		bred = sc.nextInt();
		Rectangle rec2 = new Rectangle(len,bred);
		rec2.disRecInfo();
		
		
		System.out.println("\nEnter Length for rectangle3");
		len = sc.nextInt();
		System.out.println("Enter Breadth for rectangle3");
		bred = sc.nextInt();		
		Rectangle rec3 = new Rectangle(len,bred);
		rec3.disRecInfo();
		

		
		System.out.println("\nEnter Length for rectangle4");
		len = sc.nextInt();
		System.out.println("Enter Breadth for rectangle4");
		bred = sc.nextInt();
		Rectangle rec4 = new Rectangle(len,bred);
		rec4.disRecInfo();	
		
		
		System.out.println("\nEnter Length for rectangle5");
		len = sc.nextInt();
		System.out.println("Enter Breadth for rectangle5");
		bred = sc.nextInt();
		Rectangle rec5 = new Rectangle(len,bred);
		rec5.disRecInfo();	
	}

}
