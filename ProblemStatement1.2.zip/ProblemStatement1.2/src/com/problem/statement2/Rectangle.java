package com.problem.statement2;

public class Rectangle{
    private	int length;
    private	int breadth;
    
    Rectangle(){
    	
    }
    
    Rectangle(int len,int bdth){
    	this.length=len;
    	this.breadth=bdth;
    }

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
	public int calcArea() {
		int area;
		area = this.length * this.breadth;
		return area;
	}
	public void disRecInfo() {
		System.out.println("Length is: "+this.length);
		System.out.println("Breadth is: "+this.breadth);
		System.out.println("Area of Rectangle is: "+calcArea());
	}
}
