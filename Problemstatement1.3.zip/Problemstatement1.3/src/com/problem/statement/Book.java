package com.problem.statement;

import java.util.Scanner;

public class Book{

	String Title;
	int price;
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	 public static void main(String[] args) {
		    Book myObj = new Book();
		   Scanner sc=new Scanner(System.in);
		   System.out.println("enter book name");
		   String  name=sc.nextLine();
		   System.out.println("enter book price");
		   int p=sc.nextInt();
		   
		    myObj.Title = name;  
		    myObj.price=p;
		    System.out.print("Book Title"); 
		    System.out.print("      ");
		    
		    System.out.print("Book Price");
		    System.out.println("");
		    
		    System.out.print(myObj.Title); 
		    System.out.print("            ");
		    System.out.print(myObj.price); 
		  }

}
