package com.problem.statement;



import java.util.*;
import java.lang.*;

class PlateformRequired{

static int minPlatform(int arrival[],
					int departure[],
					int n)
{
	
	
	int[] platform = new int[2361];
	int requiredPlatform = 1;
	
	for(int i = 0; i < n; i++)
	{
		
		
		++platform[arrival[i]];

		
		--platform[departure[i] + 1];
	}
	
	
	for(int i = 1; i < 2361; i++)
	{
		
		
		platform[i] = platform[i] +
					platform[i - 1];
		requiredPlatform = Math.max(requiredPlatform,
									platform[i]);
	}
	return requiredPlatform;
}


public static void main(String[] args)
{
	int arr[] = { 900, 940, 950, 1100, 1500, 1800 };
	int dep[] = { 910, 1200, 1120, 1130, 1900, 2000 };
	int n = arr.length;
	
	System.out.println("Minimum Number of " +
					"Platforms Required = " +
					minPlatform(arr, dep, n));
}
}


