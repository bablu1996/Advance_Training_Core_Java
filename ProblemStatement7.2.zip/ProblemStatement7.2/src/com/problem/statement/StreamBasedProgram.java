package com.problem.statement;

public class StreamBasedProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
