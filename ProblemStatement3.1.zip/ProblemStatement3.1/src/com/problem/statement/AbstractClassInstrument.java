package com.problem.statement;
public class AbstractClassInstrument {

	 public static void main(String[] args) {
	  Instrument instrument[]=new Instrument[10];
	  instrument[0]=new Piano();
	  instrument[1]=new Flute();
	  instrument[2]=new Guitar();
	  instrument[3]=new Piano();
	  instrument[4]=new Flute();
	  instrument[5]=new Guitar();
	  instrument[6]=new Piano();
	  instrument[7]=new Flute();
	  instrument[8]=new Guitar();
	  instrument[9]=new Piano();
	  
	
	  for(int i=0; i<instrument.length; i++) {
	   if(instrument[i] instanceof Piano) {
	    instrument[i].Play();
	   }
	   if(instrument[i] instanceof Flute) {
	    instrument[i].Play();
	   }
	   if(instrument[i] instanceof Guitar) {
	    instrument[i].Play();
	   }
	   
	  }

	 }

	}
abstract class Instrument{
	 public abstract void Play();
	}
	class Piano extends Instrument{
	 public void Play() {
	  System.out.println("Piano is playing tan tan tan tan");
	 }
	}
	class Flute extends Instrument{
	 public void Play() {
	  System.out.println("Flute is playing toot toot toot toot");
	 }
	}
	class Guitar extends Instrument{
	 public void Play() {
	  System.out.println("Guitar is playing tin tin tin");
	 }
	}