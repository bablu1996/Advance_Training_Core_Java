package com.problem.statement;

import java.util.Scanner;

public class ExpressionParser {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// TODO Auto-generated method stub
		System.out.println("Enter a mathematical expression");
		String txt = sc.nextLine();
		String str[] = txt.split(" ");
		int n =str.length;
		for(int i=0; i<n;i++) {
			System.out.println(str[i]);
		}
	}

}
