package com.problem.statement;

import java.util.Scanner;

public class AcceptTwoNumber {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		int n1 = sc.nextInt();
		System.out.println("Enter the second number");
		int n2 = sc.nextInt();
		System.out.print(n1 + " ");
		System.out.print(n2);
		for(int i=0;i<=13;i++) {
			int nextnum = n1+n2;
			System.out.print(" "+ nextnum);
			n1=n2;
			n2 = nextnum;
		}
		
	}
}
