package com.problem.statement;

public class AcceptTwoFileName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
