package com.problem.statement;

import java.util.ArrayList;
import java.util.Scanner;

public class AddListOfStudents {
	public static void main(String[] args) {
		ArrayList<String> a1 = new ArrayList<String>();
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number of students:");
		n = sc.nextInt();
		System.out.println("enter the student names:");
		
		for (int i = 0; i < n; i++) {
			String name = sc.nextLine();
			a1.add(name);
		}
		
		System.out.println("enter the student names to be searched:");
		String srchname = sc.nextLine();
		int pos = a1.indexOf("srchname");
		if(pos<0) {
			System.out.println("Searched student does not exist");
		}
		else
			System.out.println("The student "+srchname+" exists at position "+ pos);
		
	}
}