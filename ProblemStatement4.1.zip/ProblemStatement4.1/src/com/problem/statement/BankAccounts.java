package com.problem.statement;

public class BankAccounts {
	int accNo;
	String custName;
	String accType;
	float balance;
	
	public BankAccounts(int accNo, String custName, String acctype, float balance){
		this.accNo = accNo;
		this.custName=custName;
		this.accType= acctype;
		this.balance = balance;
	}
	
	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
	public float getBalance() {
		
		return balance;
	}

	public void LowBalanceException() {
		System.out.println("The balance is low");
	}
	
	public void NegativeAmountException() {
		System.out.println("The deposit amount cannot be negative");
	}
	
	public void deposit(float amt) {
		if(amt<0) {
			NegativeAmountException();
		}
		else {
			this.balance = getBalance() + amt;
		}
	}
	public void withdraw(float amt) {
		if(this.getBalance()<1000 & this.getAccType().equalsIgnoreCase("savings"))
			LowBalanceException();
		else if(this.getBalance()<5000 & this.getAccType().equalsIgnoreCase("current"))
			LowBalanceException();
		else if(this.balance<amt)
			LowBalanceException();
		else
			this.balance = getBalance() - amt;
	}
	public float displayBalance() {
		if(this.getBalance()<1000 & this.getAccType().equalsIgnoreCase("savings"))
			LowBalanceException();
		else if(this.getBalance()<5000 & this.getAccType().equalsIgnoreCase("current"))
			LowBalanceException();
		
		return this.balance;
	}
	public static void main(String args[]) {
		BankAccounts obj = new BankAccounts(223322,"Biki","Savings",1000);
		obj.withdraw(500);
		float balance = obj.displayBalance();
		System.out.println(balance);
	}
}
