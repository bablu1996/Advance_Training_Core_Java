package com.problem.statement;
import java.util.Scanner;
import com.problem.statement.*;
public class TestRectangle {
	
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		float len;
		float wid;
		Rectangle rec1 = new Rectangle();
		System.out.println("Enter Length for rectangle1");
		len = sc.nextFloat();
		rec1.setLength(len);
		System.out.println("Enter Breadth for rectangle1");
		wid = sc.nextFloat();
		rec1.setwidth(wid);
		rec1.disRecInfo();
		
		
		
		Rectangle rec2 = new Rectangle();
		System.out.println("Enter Length for rectangle2");
		len = sc.nextFloat();
		rec2.setLength(len);
		System.out.println("Enter Breadth for rectangle2");
		wid = sc.nextFloat();
		rec2.setwidth(wid);
		rec2.disRecInfo();
		
		
		Rectangle rec3 = new Rectangle();
		System.out.println("Enter Length for rectangle3");
		len = sc.nextFloat();
		rec3.setLength(len);
		System.out.println("Enter Breadth for rectangle3");
		wid = sc.nextFloat();
		rec3.setwidth(wid);
		rec3.disRecInfo();
		

		
		Rectangle rec4 = new Rectangle();
		System.out.println("Enter Length for rectangle4");
		len = sc.nextFloat();
		rec4.setLength(len);
		System.out.println("Enter Breadth for rectangle4");
		wid = sc.nextFloat();
		rec4.setwidth(wid);
		rec4.disRecInfo();
		
		
		Rectangle rec5 = new Rectangle();
		System.out.println("Enter Length for rectangle5");
		len = sc.nextFloat();
		rec5.setLength(len);
		System.out.println("Enter Breadth for rectangle5");
		wid = sc.nextFloat();
		rec5.setwidth(wid);
		rec5.disRecInfo();	
	}

}
