package com.problem.statement;

public class Rectangle{
    private	float length;
    private	float width;
    
    Rectangle(){
    	this.length=1;
    	this.width=1;
    }
    
    Rectangle(float len,float wid){
    	this.length=len;
    	this.width=wid;
    }

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		if(length>=0.0 && length<=20.0)
			this.length = length;
		else {
			System.out.println("Length should be in range of 0.0 to 20.0");
			System.exit(0);
		}
	}

	public float getwidth() {
		return width;
	}

	public void setwidth(float width) {
		if(width>=0.0 && width<=20.0)
			this.width = width;
		else {
			System.out.println("Width should be in range of 0.0 to 20.0");
			System.exit(0);
			}
	}
	public float calcArea() {
		float area;
		area = this.length * this.width;
		return area;
	}
	public float calcperimeter() {
		float perimeter;
		perimeter = 2*(this.length+this.width);
		return perimeter;
		
	}
	public void disRecInfo() {
		System.out.println("Length is: "+this.length);
		System.out.println("width is: "+this.width);
		System.out.println("Area of Rectangle is: "+calcArea());
		System.out.println("Perimeter of Rectangle is: "+calcperimeter());
	}
}
