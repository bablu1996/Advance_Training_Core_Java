package com.problem.statement;

import java.util.Scanner;

public class CommandLine {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		String str;
		System.out.println("Enter the String"); 
		str = sc.nextLine();
		int len = str.length();
		System.out.println("Length of the String is: "+ len);
		System.out.println("String in Upper Case is: "+ str.toUpperCase()); 
		
		StringBuffer newStr =new StringBuffer();
	      for(int i = str.length()-1; i >= 0 ; i--) {
	         newStr = newStr.append(str.charAt(i));
	      }
	      if(str.equalsIgnoreCase(newStr.toString())) {
	         System.out.println("String is palindrome");
	      } else {
	         System.out.println("String is not palindrome");
	      }
		
	}

}
