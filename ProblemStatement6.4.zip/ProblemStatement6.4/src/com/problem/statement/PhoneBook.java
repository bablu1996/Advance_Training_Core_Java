package com.problem.statement;
import java.io.*;
import java.sql.*;
import java.util.*;
 
public class PhoneBook {
	public static String help_msg=	" 1)Add contact  2)Search  3) Exit :";
	public static void main(String[] args) {		
		System.out.println("\n\n*** Welcome to MyPhone Book ***\n\n");
		Scanner s=new Scanner(System.in);		
		for(;;){
				System.out.print("[Main Menu] "+help_msg+"\n:");
				int command=s.nextInt();			
				if (command == 1){
					System.out.print("Type in contact details in the format: name and phone\n:");
 
				}else if (command ==2){
					System.out.print("Type in the name you are searching for :\n:");
 
				}else if (command==3){
					System.out.println("Closing Program");
					System.exit(0);
				}else{					
					System.out.print("Enter a valid Option \n:");
				}
 
		}
 
	}
 
}