package com.mycompany.app;

import java.util.List;
import java.util.Scanner;
import com.mycompany.dao.*;
import com.mycompany.domain.Product;
import com.mycompany.dao.*;
public class ProductManagementApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		displayOptions();
		optionHandling();
		
	}
    
	
	 static void displayOptions(){
		System.out.println("A.View Products");
		System.out.println("B.Add Product");
		System.out.println("C.Update Product");
		System.out.println("D.Delete Product");
		System.out.println("E.Search Product");
		System.out.println("F.Exit");
		}
	 static void delete() {
		 
	 }

static void view() {
	List<Product> list=ProductManagementDAO.getAllProduct();
	for(Product prd:list) {
        System.out.println("\nProduct ID: "+prd.getProductId());
        System.out.println("Product Name: "+prd.getProductName());
        System.out.println("Product Price: "+prd.getProductPrice()+"\n");
    }
}

	 private static void optionHandling() {
		 Product p = new Product();
		Character option;	
		int productid,productprice;
		String productNameStr;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("\n\n---------------------------------");
			System.out.println("Enter an Option");
			System.out.println("---------------------------------");
			option =sc.next().charAt(0);
			switch(option.toUpperCase(option)) {
			case 'A':
				view();
				
				break;
			case 'B':
				System.out.println("\n\n---------------------------------");
				System.out.println("Enter Product ID");
				System.out.println("---------------------------------");
				productid = sc.nextInt();
				p.setProductId(productid);
				System.out.println("---------------------------------");
				System.out.println("Enter Product Name");
				System.out.println("---------------------------------");
				productNameStr = sc.next();
				p.setProductName(productNameStr);
				System.out.println("---------------------------------");
				System.out.println("Enter Product Price");
				System.out.println("---------------------------------");
				productprice = sc.nextInt();
				p.setProductPrice(productprice);
				int result = ProductManagementDAO.insertProduct(p);
				if(result==1) {
					System.out.print("Product Added Successfully");
					view();
					
					
				}
				else
					System.out.print("Product Not Added");
				break;
			case 'C':
				System.out.println("\n\n---------------------------------");
				System.out.println("Enter Product ID");
				System.out.println("---------------------------------");
				productid = sc.nextInt();
				p.setProductId(productid);
				System.out.println("---------------------------------");
				System.out.println("Enter Product Name");
				System.out.println("---------------------------------");
				productNameStr = sc.next();
				p.setProductName(productNameStr);
				System.out.println("---------------------------------");
				System.out.println("Enter Product Price");
				System.out.println("---------------------------------");
				productprice = sc.nextInt();
				p.setProductPrice(productprice);
				int updateres = ProductManagementDAO.updateProduct(p);
				if(updateres == 1) {
					System.out.print("Product Updated Successfully");
					view();
					
					
					
				}
				else
					System.out.print("Product Not Updated");
				
				break;
			case 'D':
				System.out.println("\n\n---------------------------------");
				System.out.println("Enter Product ID");
				System.out.println("---------------------------------");
				int idtodelete = sc.nextInt();
				int delres = ProductManagementDAO.deleteProduct(idtodelete);
				if(delres==1) {
					System.out.print("Product deleted Successfully");
					view();
					
					
				}
				else
					System.out.print("Product Not Deleted");
				break;
			case 'E':
				System.out.println("\n\n---------------------------------");
				System.out.println("Enter Product ID");
				System.out.println("---------------------------------");
				int idtosearch = sc.nextInt();
				p = ProductManagementDAO.getProductById(idtosearch);
				productid = p.getProductId();
				productNameStr = p.getProductName();
				productprice = p.getProductPrice();
				System.out.println("Product ID: "+ productid);
				System.out.println("Product Name: "+ productNameStr);
				System.out.println("Product Price: "+ productprice);
				break;
			case 'F': System.exit(0);
				break;
			default: 	
				System.out.println("Invalid Option Selected");
			}
	 }
}
