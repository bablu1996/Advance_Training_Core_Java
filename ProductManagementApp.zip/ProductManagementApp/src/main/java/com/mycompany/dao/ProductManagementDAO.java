package com.mycompany.dao;

import java.sql.*;
import java.util.*;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.Product;




public class ProductManagementDAO {

	
	

    public static int insertProduct(Product e){  
        int status=0;  
        try{  
            Connection con=DBUtil.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "insert into product(product_id,product_Name,product_price) values (?,?,?)");  
            ps.setInt(1,e.getProductId());  
            ps.setString(2,e.getProductName());  
            ps.setInt(3,e.getProductPrice());  
                          
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    } 
    public static int updateProduct(Product e){  
        int status=0;  
        try{  
            Connection con=DBUtil.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "update product set product_id=?,product_Name=?,product_price=? where product_id=?");  
            ps.setInt(1,e.getProductId());  
            ps.setString(2,e.getProductName());  
            ps.setInt(3,e.getProductPrice()); 
            ps.setInt(4,e.getProductId());    
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    } 
    public static int deleteProduct(int id){  
        int status=0;  
        try{  
            Connection con=DBUtil.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from product where product_id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return status;  
    }  
    public static Product getProductById(int id){  
    	Product e=new Product();  
          
        try{  
            Connection con=DBUtil.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from product where product_id=?");  
            ps.setInt(1,id);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){ 
            	e.setProductId(rs.getInt(1));
            	e.setProductName(rs.getString(2));
            	e.setProductPrice(rs.getInt(3));
                
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return e;  
    }  
    public static List<Product> getAllProduct(){  
        List<Product> list=new ArrayList<Product>();  
          
        try{  
            Connection con=DBUtil.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from product");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                Product e=new Product();  
                e.setProductId(rs.getInt(1));  
                e.setProductName(rs.getString(2));  
                e.setProductPrice(rs.getInt(3)); 
                list.add(e);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  
}
