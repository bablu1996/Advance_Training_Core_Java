package com.problem.statement;

public class medicineInfo {
	public void displayLabel() {
		System.out.println("Emcure Pharmaceuticals");
		System.out.println("Pune,Maharastra");
	}
}

class Tablet extends medicineInfo {
	@Override
	public void displayLabel() {
		System.out.println("store in a cool & dry place");
	}
}

class Syrup extends medicineInfo {
	@Override
	public void displayLabel() {
		System.out.println("Consumption as directed by the physician");
	}
}

class Ointment extends medicineInfo {
	@Override
	public void displayLabel() {
		System.out.println("for external use only");
	}
}
